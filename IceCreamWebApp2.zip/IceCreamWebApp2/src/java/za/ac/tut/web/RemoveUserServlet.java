package za.ac.tut.web;

import za.ac.tut.model.bl.UserFacadeLocal;
import za.ac.tut.model.bl.OrderFacadeLocal;
import za.ac.tut.model.entities.User;
import za.ac.tut.model.entities.Order;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/removeUser")
public class RemoveUserServlet extends HttpServlet {

    @EJB
    private UserFacadeLocal userFacade;

    @EJB
    private OrderFacadeLocal orderFacade;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve user ID from request
        String userIdParam = request.getParameter("userId");

        if (userIdParam == null) {
            response.sendRedirect("user_list.jsp?error=missing_user_id");
            return;
        }

        Long userId = Long.parseLong(userIdParam);

        // Find the user in the database
        User userToRemove = userFacade.find(userId);

        if (userToRemove != null) {
            // Find and remove all orders associated with the user
            List<Order> orders = orderFacade.findAll();
            for (Order order : orders) {
                if (order.getUser().getId().equals(userId)) {
                    orderFacade.remove(order);
                }
            }

            // Remove the user
            userFacade.remove(userToRemove);

            response.sendRedirect("remove_user_outcome.jsp");
        } else {
            // User not found
            response.sendRedirect("user_list.jsp?error=user_not_found");
        }
    }
}