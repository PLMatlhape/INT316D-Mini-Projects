package za.ac.tut.web;

import za.ac.tut.model.entities.User;
import za.ac.tut.model.bl.UserFacadeLocal;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @EJB
    private UserFacadeLocal userFacade;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Check if user is an admin
        if (email.equals("icecream@admin.co.za") && password.equals("admin@123")) {
            // Store admin in session
            HttpSession session = request.getSession();
            session.setAttribute("admin", true);

            // Redirect to admin portal
            response.sendRedirect("admin_portal.jsp");
            return;
        }

        // Check user credentials for regular users
        List<User> users = userFacade.findAll();
        User matchedUser = null;

        for (User u : users) {
            if (u.getEmail().equals(email) && u.getPassword().equals(password)) {
                matchedUser = u;
                break;
            }
        }

        if (matchedUser != null) {
            // Store user in session
            HttpSession session = request.getSession();
            session.setAttribute("user", matchedUser);

            // Redirect to product list or dashboard
            response.sendRedirect("ice_cream_menu.jsp");
        } else {
            // Invalid login, redirect back to login with error
            response.sendRedirect("login.jsp?error=1");
        }
    }
}