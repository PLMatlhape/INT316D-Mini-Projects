/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.model.bl.OrderFacadeLocal;
import za.ac.tut.model.bl.ProductFacadeLocal;
import za.ac.tut.model.entities.Order;
import za.ac.tut.model.entities.Product;
import za.ac.tut.model.entities.User;

/**
 *
 * @author pule
 */
public class CheckoutServlet extends HttpServlet {

    @EJB
    ProductFacadeLocal pfl;
    @EJB
    OrderFacadeLocal ofl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String productName = request.getParameter("productName");
        Integer quantity = Integer.parseInt(request.getParameter("quantity"));

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect("login.jsp?error=not_logged_in");
            return;
        }

        double price;

        if (productName.equals("MAX Classic")
                || productName.equals("MAX Chocolate Therapy")
                || productName.equals("MAX Ruby Chocolate")
                || productName.equals("MAX White Almond")) {

            price = 20.0;

        } else if (productName.equals("Drumstick Sundae")) {

            price = 25.0;

        } else {

            price = 15.0;
        }

        // Calculate total price
        double totalPrice = price * quantity;

        // Create product object
        Product product = getProduct(productName, price);

        // Create order and set User object
        Order order = createOrder(user, product, quantity, totalPrice);

        // Save product in database
        pfl.create(product);

        // Save order in database
        ofl.create(order);

        // Set attributes for forwarding
        request.setAttribute("prod", product);
        request.setAttribute("price", price);
        request.setAttribute("order", order);

        request.getRequestDispatcher("purchase_outcome.jsp").forward(request, response);
    }

// Method to create an order
    private Order createOrder(User user, Product product, Integer quantity, Double totalPrice) {
        Order order = new Order();
        order.setUser(user); // Set User object instead of userId
        order.setProduct(product);
        order.setQuantity(quantity);
        order.setTotalPrice(totalPrice);
        return order;
    }

// Method to create a product object
    private Product getProduct(String productName, Double price) {
        Product prod = new Product();
        prod.setProductName(productName);
        prod.setPrice(price);
        return prod;
    }
}
