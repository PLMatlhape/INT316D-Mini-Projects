package za.ac.tut.web;

import za.ac.tut.model.entities.User;
import za.ac.tut.model.bl.UserFacadeLocal;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Date;

@WebServlet("/RegisterServlet.do")
public class RegisterServlet extends HttpServlet {

    @EJB
    private UserFacadeLocal userFacade;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            // Retrieve form data
            Long id = Long.parseLong(request.getParameter("id"));
            String name = request.getParameter("name");
            String surname = request.getParameter("surname");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String roomAddress = request.getParameter("roomAddress");

            // Create User object
            User user = new User(id, name, surname, email, password, roomAddress, new Date());

            // Persist user using EJB
            userFacade.create(user);

            // Redirect to login page after successful registration
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("register.jsp?error=1");
        }
    }
}
