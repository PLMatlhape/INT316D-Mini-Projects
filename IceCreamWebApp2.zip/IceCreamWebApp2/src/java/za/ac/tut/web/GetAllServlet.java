/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.OrderFacadeLocal;
import za.ac.tut.model.bl.ProductFacadeLocal;
import za.ac.tut.model.bl.UserFacadeLocal;
import za.ac.tut.model.entities.Order;
import za.ac.tut.model.entities.Product;
import za.ac.tut.model.entities.User;

/**
 *
 * @author pule
 */
public class GetAllServlet extends HttpServlet {
    @EJB
    UserFacadeLocal ufl;
    @EJB
    ProductFacadeLocal pfl;
    @EJB
    OrderFacadeLocal ofl;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List<User> users = ufl.findAll();
        List<Product> products = pfl.findAll();
        List<Order> orders = ofl.findAll();
        
        request.setAttribute("users", users);
        request.setAttribute("products", products);
        request.setAttribute("orders", orders);
        
        RequestDispatcher disp = request.getRequestDispatcher("get_all_outcome.jsp");
        disp.forward(request, response);
    }

}
